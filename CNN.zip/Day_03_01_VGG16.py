# Day_03_01_VGG16.py
import tensorflow.keras as keras


# 퀴즈
# VGG16 모델을 구축해서 파라미터 갯수가 1억개가 넘는지 확인하세요
def vgg16_dense():
    model = keras.Sequential()
    model.add(keras.layers.InputLayer([224, 224, 3]))
    model.add(keras.layers.Conv2D(64, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(64, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.MaxPool2D([2, 2], 2))

    model.add(keras.layers.Conv2D(128, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(128, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.MaxPool2D([2, 2], 2))

    model.add(keras.layers.Conv2D(256, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(256, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(256, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.MaxPool2D([2, 2], 2))

    model.add(keras.layers.Conv2D(512, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(512, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(512, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.MaxPool2D([2, 2], 2))

    model.add(keras.layers.Conv2D(512, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(512, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(512, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.MaxPool2D([2, 2], 2))

    model.add(keras.layers.Flatten())

    model.add(keras.layers.Dense(4096, activation='relu'))
    model.add(keras.layers.Dense(4096, activation='relu'))
    model.add(keras.layers.Dense(1000, activation='softmax'))

    model.summary()


# 퀴즈
# 마지막에 오는 덴스 레이어들을 1x1 필터의 컨볼루션 레이어로 교체하세요
def vgg16_conv1x1():
    model = keras.Sequential()
    model.add(keras.layers.InputLayer([224, 224, 3]))
    model.add(keras.layers.Conv2D(64, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(64, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.MaxPool2D([2, 2], 2))

    model.add(keras.layers.Conv2D(128, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(128, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.MaxPool2D([2, 2], 2))

    model.add(keras.layers.Conv2D(256, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(256, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(256, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.MaxPool2D([2, 2], 2))

    model.add(keras.layers.Conv2D(512, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(512, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(512, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.MaxPool2D([2, 2], 2))

    model.add(keras.layers.Conv2D(512, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(512, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.Conv2D(512, [3, 3], 1, 'same', activation='relu'))
    model.add(keras.layers.MaxPool2D([2, 2], 2))

    model.add(keras.layers.Conv2D(4096, [7, 7], 1, 'valid', activation='relu'))
    model.add(keras.layers.Conv2D(4096, [1, 1], 1, 'valid', activation='relu'))
    model.add(keras.layers.Conv2D(1000, [1, 1], 1, 'valid'))
    model.add(keras.layers.Flatten())
    model.add(keras.layers.Softmax())

    model.summary()


vgg16_dense()
# vgg16_conv1x1()
