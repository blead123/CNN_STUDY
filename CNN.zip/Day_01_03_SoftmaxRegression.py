# Day_01_03_SoftmaxRegression.py
import tensorflow.keras as keras
import pandas as pd
import numpy as np
from sklearn import preprocessing, model_selection



def softmax_regression_onehot():
   
    x = [[1, 2],        
         [2, 1],
         [4, 5],        
         [5, 4],
         [8, 9],        
         [9, 8]]
    y = [[0, 0, 1],    
         [0, 0, 1],
         [0, 1, 0],
         [0, 1, 0],
         [1, 0, 0],
         [1, 0, 0]]

    model = keras.Sequential()
    model.add(keras.layers.Dense(3, activation=keras.activations.softmax))

    model.compile(optimizer=keras.optimizers.SGD(0.1),
                  loss=keras.losses.categorical_crossentropy,
                  metrics='acc')

    model.fit(x, y, epochs=20, verbose=2)
    print(model.evaluate(x, y, verbose=0))

    p = model.predict(x)
    print(p)

    p_arg = np.argmax(p, axis=1)
    y_arg = np.argmax(y, axis=1)
    print(p_arg)
    print(y_arg)

    print('acc :', np.mean(p_arg == y_arg))


def softmax_regression_sparse():

    x = [[1, 2],        
         [2, 1],
         [4, 5],        
         [5, 4],
         [8, 9],        
         [9, 8]]
    y = [2, 2, 1, 1, 0, 0]

    model = keras.Sequential()
    model.add(keras.layers.Dense(3, activation=keras.activations.softmax))

    model.compile(optimizer=keras.optimizers.SGD(0.1),
                  loss=keras.losses.sparse_categorical_crossentropy,
                  metrics='acc')

    model.fit(x, y, epochs=20, verbose=2)
    print(model.evaluate(x, y, verbose=0))

    p = model.predict(x)
    print(p)

    p_arg = np.argmax(p, axis=1)
    print(p_arg)    # [1 2 1 1 1 1]
    print(y)        # [2, 2, 1, 1, 0, 0]

    print('acc :', np.mean(p_arg == y))



def softmax_regression_iris():
    iris = pd.read_csv('data/iris_onehot.csv')
    # print(iris)

    x = iris.values[:, :-3]
    y = iris.values[:, -3:]

    x_train, x_test, y_train, y_test = model_selection.train_test_split(x, y, train_size=0.7)

    model = keras.Sequential()
    model.add(keras.layers.Dense(3, activation=keras.activations.softmax))

    model.compile(optimizer=keras.optimizers.SGD(0.01),
                  loss=keras.losses.categorical_crossentropy,
                  metrics='acc')

    model.fit(x_train, y_train, epochs=100, verbose=2)
    print(model.evaluate(x_test, y_test, verbose=0))

    p = model.predict(x_test)

    p_arg = np.argmax(p, axis=1)
    y_arg = np.argmax(y_test, axis=1)
    print(y_arg)

    print('acc :', np.mean(p_arg == y_arg))


def softmax_regression_iris_onehot():
    iris = pd.read_csv('data/iris.csv')
    # print(iris)

    x = iris.values[:, :-1]
    y = iris.values[:, -1:]
    # print(x.shape, y.shape)              

    # print(iris.values.dtype)           

    x = np.float32(x)

    lb = preprocessing.LabelBinarizer()
    y = lb.fit_transform(y)
    # print(y.shape)                       
    # print(y[:3])                         

    x_train, x_test, y_train, y_test = model_selection.train_test_split(x, y, train_size=0.7)

    model = keras.Sequential()
    model.add(keras.layers.Dense(3, activation=keras.activations.softmax))

    model.compile(optimizer=keras.optimizers.SGD(0.01),
                  loss=keras.losses.categorical_crossentropy,
                  metrics='acc')

    model.fit(x_train, y_train, epochs=100, verbose=2)
    print(model.evaluate(x_test, y_test, verbose=0))

  


def softmax_regression_iris_sparse():
    iris = pd.read_csv('data/iris.csv')
    # print(iris)

    x = iris.values[:, :-1]
    y = iris.values[:, -1:]


    x = np.float32(x)

    le = preprocessing.LabelEncoder()
    y = le.fit_transform(y)


    x_train, x_test, y_train, y_test = model_selection.train_test_split(x, y, train_size=0.7)

    model = keras.Sequential()
    model.add(keras.layers.Dense(3, activation=keras.activations.softmax))

    model.compile(optimizer=keras.optimizers.SGD(0.01),
                  loss=keras.losses.sparse_categorical_crossentropy,
                  metrics='acc')

    model.fit(x_train, y_train, epochs=100, verbose=2)
    print(model.evaluate(x_test, y_test, verbose=0))

    p = model.predict(x_test)

    p_arg = np.argmax(p, axis=1)
    print('acc :', np.mean(p_arg == y_test))



softmax_regression_iris_sparse()






