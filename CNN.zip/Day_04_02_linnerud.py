# Day_04_02_linnerud.py
import numpy as np
import tensorflow.keras as keras
from sklearn import datasets, preprocessing

# bunch = datasets.load_linnerud()
# print(bunch)
# print(bunch.keys())
# # ['data', 'feature_names', 'target', 'target_names', 'frame', 'DESCR',
# # 'data_filename', 'target_filename', 'data_module']
#
# print(bunch['feature_names'])   # ['Chins', 'Situps', 'Jumps']
# print(bunch['target_names'])    # ['Weight', 'Waist', 'Pulse']

# 퀴즈
# linnerud 데이터셋에 대해 동작하는 모델을 구축하세요
x, y = datasets.load_linnerud(return_X_y=True)
# print(x.shape, y.shape)       # (20, 3) (20, 3)
# print(x[:3])                  # [[  5. 162.  60.] [  2. 110.  60.] [ 12. 101. 101.]]
# print(y[:3])                  # [[191.  36.  50.] [189.  37.  52.] [193.  38.  58.]]

# x = preprocessing.scale(x)
x = preprocessing.minmax_scale(x)

y1 = y[:, 0:1]
y2 = y[:, 1:2]
y3 = y[:, 2:3]

inputs = keras.Input([3])
output = keras.layers.Dense(12, activation='relu')(inputs)
output = keras.layers.Dense(6, activation='relu')(output)

output1 = keras.layers.Dense(4, activation='relu', name='Chins')(output)
output1 = keras.layers.Dense(1)(output1)

output2 = keras.layers.Dense(4, activation='relu', name='Situps')(output)
output2 = keras.layers.Dense(1)(output2)

output3 = keras.layers.Dense(4, activation='relu', name='Jumps')(output)
output3 = keras.layers.Dense(1)(output3)

model = keras.Model(inputs, [output1, output2, output3])
model.summary()

model.compile(optimizer=keras.optimizers.Adam(0.01),
              loss=keras.losses.mse,
              metrics='mae')            # Mean Absolute Error

model.fit(x, [y1, y2, y3], epochs=100, verbose=2)
print(model.evaluate(x, [y1, y2, y3], verbose=0))

# 퀴즈
# predict 함수의 결과에 대해 mae 결과를 보여주세요
p = model.predict(x)
print(type(p), len(p))      # <class 'list'> 3
print(type(p[0]))           # <class 'numpy.ndarray'>
print(p[0].shape)           # (20, 1)

p1, p2, p3 = model.predict(x)
print('mae 1 :', np.mean(np.absolute(p1 - y1)))
print('mae 2 :', np.mean(np.absolute(p2 - y2)))
print('mae 3 :', np.mean(np.absolute(p3 - y3)))
# mae 1 : 48.659912490844725
# mae 2 : 9.512633037567138
# mae 3 : 12.911919689178466

p = np.hstack(p)        # np.hstack([p1, p2, p3])
print(p.shape)          # (20, 3)

errors = (p - y)
print(errors.shape)     # (20, 3)
print(errors[:3])
# [[-28.0390625   -6.94805145  -2.46004105]
#  [-52.44343567 -12.74814034 -12.18215942]
#  [-13.53451538  -6.2629528   -6.0255394 ]]
# [[28.0390625   6.94805145  2.46004105]

abs_errors = np.abs(errors)
print(abs_errors[:3])
# [[28.0390625   6.94805145  2.46004105]
#  [52.44343567 12.74814034 12.18215942]
#  [13.53451538  6.2629528   6.0255394 ]]

print('mae :', np.mean(abs_errors, axis=0))     # 수직 방향 평균
# mae : [48.65991249  9.51263304 12.91191969]
