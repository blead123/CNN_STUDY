# Day_04_01_CarEvaluation.py
import numpy as np
import tensorflow.keras as keras
from sklearn import preprocessing, model_selection
import pandas as pd

# 퀴즈
# car.data 파일을 읽어서
# 70%에 대해 학습하고 30%에 대해 결과를 알려주는 모델을 구축하세요


# 1. 팬다스로 파일 읽기
# 2. values 속성으로 실제 데이터만 가져오기 (object)
# 3. 사이킷런의 전처리 기능으로 문자열을 숫자로 변환
# 4. 컬럼별로 변환한 결과를 하나로 통합
# 5. 변환된 결과를 학습/검사 데이터셋으로 분할
# 6. 딥러닝 모델 구축
def car_model_sparse():
    # 1. 팬다스로 파일 읽기
    cars = pd.read_csv('data/car.data', header=None)
    # print(cars)

    # 2. values 속성으로 실제 데이터만 가져오기 (object)
    values = cars.values
    # np.random.shuffle(values)     # 5-1번 코드와 대응

    # 3. 사이킷런의 전처리 기능으로 문자열을 숫자로 변환
    enc = preprocessing.LabelEncoder()

    buying = enc.fit_transform(values[:, 0])
    maint = enc.fit_transform(values[:, 1])
    doors = enc.fit_transform(values[:, 2])
    persons = enc.fit_transform(values[:, 3])
    lug_boot = enc.fit_transform(values[:, 4])
    safety = enc.fit_transform(values[:, 5])
    y = enc.fit_transform(values[:, 6])  # class
    # print(buying[:5])     # [3 3 3 3 3]

    # 4. 컬럼별로 변환한 결과를 하나로 통합
    # 4-1번
    # buying = buying.reshape(-1, 1)
    # maint = maint.reshape(-1, 1)
    # doors = doors.reshape(-1, 1)
    # persons = persons.reshape(-1, 1)
    # lug_boot = lug_boot.reshape(-1, 1)
    # safety = safety.reshape(-1, 1)
    # print(buying.shape)               # (1728,) -> (1728, 1)
    #
    # x = np.hstack([buying, maint, doors, persons, lug_boot, safety])

    # 4-1번
    # print(buying[np.newaxis].shape)       # (1, 1728)
    # print(buying[:, np.newaxis].shape)    # (1728, 1)

    x = [buying, maint, doors, persons, lug_boot, safety]
    # print(np.int32(x).shape)              # (6, 1728)

    x = np.transpose(x)  # 전치 행렬
    # print(x.shape)                        # (1728, 6)

    # 2행 3열을 전치하면 3행 2열
    # 0 1 2
    # 3 4 5
    # ->
    # 0 3
    # 1 4
    # 2 5

    # 5. 변환된 결과를 학습/검사 데이터셋으로 분할
    # 5-1번 : 결과가 잘 나오지 않음
    # train_size = int(len(x) * 0.7)
    # x_train, x_test = x[:train_size], x[train_size:]
    # y_train, y_test = y[:train_size], y[train_size:]
    # print(x_train.shape, x_test.shape)    # (1209, 6) (519, 6)
    # print(y_train.shape, y_test.shape)    # (1209,) (519,)

    # 5-2번 : 결과가 잘 나옴
    x_train, x_test, y_train, y_test = model_selection.train_test_split(x, y, train_size=0.7)

    # 6. 딥러닝 모델 구축
    model = keras.Sequential()
    model.add(keras.layers.Dense(256, activation='relu'))
    model.add(keras.layers.Dense(64, activation='relu'))
    model.add(keras.layers.Dense(4, activation='softmax'))

    model.compile(optimizer=keras.optimizers.Adam(0.01),
                  loss=keras.losses.sparse_categorical_crossentropy,
                  metrics='acc')

    model.fit(x_train, y_train, epochs=20, batch_size=32, verbose=2)
    print(model.evaluate(x_test, y_test, verbose=0))


def car_model_onehot():
    # 1. 팬다스로 파일 읽기
    cars = pd.read_csv('data/car.data', header=None,
                       names=['buying', 'maint', 'doors', 'persons', 'lug_boot', 'safety', 'class'])
    # print(cars)

    # 2. values 속성으로 실제 데이터만 가져오기 (object)
    # 컬럼에 직접 접근하기 때문에 values를 따로 추출하지 않는다
    print(cars['buying'])               # Series 클래스
    print(cars['buying'].values)

    # 3. 사이킷런의 전처리 기능으로 문자열을 숫자로 변환
    enc = preprocessing.LabelBinarizer()            # 원핫 인코딩

    buying = enc.fit_transform(cars['buying'])
    maint = enc.fit_transform(cars['maint'])
    doors = enc.fit_transform(cars['doors'])
    persons = enc.fit_transform(cars['persons'])
    lug_boot = enc.fit_transform(cars['lug_boot'])
    safety = enc.fit_transform(cars['safety'])
    y = enc.fit_transform(cars['class'])            # 원핫 벡터
    print(buying.shape)     # (1728, 4)
    print(buying[:3])       # [[0 0 0 1] [0 0 0 1] [0 0 0 1]]

    # 퀴즈
    # LabelBinarizer 클래스를 사용해서 변환한 결과에 대해 모델을 수정하세요

    # 4. 컬럼별로 변환한 결과를 하나로 통합
    x = np.hstack([buying, maint, doors, persons, lug_boot, safety])
    print(x.shape, y.shape)          # (1728, 21) (1728, 4)

    # 5. 변환된 결과를 학습/검사 데이터셋으로 분할
    x_train, x_test, y_train, y_test = model_selection.train_test_split(x, y, train_size=0.7)

    # 6. 딥러닝 모델 구축
    model = keras.Sequential()
    model.add(keras.layers.Dense(256, activation='relu'))
    model.add(keras.layers.Dense(64, activation='relu'))
    model.add(keras.layers.Dense(4, activation='softmax'))

    model.compile(optimizer=keras.optimizers.Adam(0.01),
                  loss=keras.losses.categorical_crossentropy,
                  metrics='acc')

    model.fit(x_train, y_train, epochs=20, batch_size=32, verbose=2)
    print(model.evaluate(x_test, y_test, verbose=0))


# car_model_sparse()
car_model_onehot()
