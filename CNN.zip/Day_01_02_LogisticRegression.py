# Day_01_02_LogisticRegression.py
import tensorflow.keras as keras
import pandas as pd
import numpy as np
from sklearn import preprocessing



def logistic_regression():
    
    x = [[1, 2],        
         [2, 1],
         [4, 5],        
         [5, 4],
         [8, 9],
         [9, 8]]
    y = [[0],
         [0],
         [1],
         [1],
         [1],
         [1]]

    model = keras.Sequential()
    model.add(keras.layers.Dense(1, activation=keras.activations.sigmoid))

    model.compile(optimizer=keras.optimizers.SGD(0.1),
                  loss=keras.losses.binary_crossentropy,
                  metrics='acc')

    model.fit(x, y, epochs=20, verbose=2)

    p = model.predict(x)
    print(p)

    p_bool = (p > 0.5)
    print(p_bool)

    equals = (p_bool == y)
    print(equals)

    print('acc :', np.mean(equals))


def logistic_regression_pima():

    pima = pd.read_csv('data/pima-indians-diabetes.csv',
                       skiprows=9, header=None)
    

    x = pima.values[:, :-1]
    y = pima.values[:, -1:]
     x = preprocessing.scale(x)


   
    train_size = int(len(x) * 0.7)
    x_train, x_test = x[:train_size], x[train_size:]
    y_train, y_test = y[:train_size], y[train_size:]
  
    model = keras.Sequential()
    model.add(keras.layers.Dense(1, activation=keras.activations.sigmoid))

    model.compile(optimizer=keras.optimizers.SGD(0.01),
                  loss=keras.losses.binary_crossentropy,
                  metrics='acc')

    model.fit(x_train, y_train, epochs=200, batch_size=32, verbose=2)

    p = model.predict(x_test)
    p_bool = (p > 0.5)

    print('acc :', np.mean(p_bool == y_test))



logistic_regression_pima()


