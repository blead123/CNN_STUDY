# Day_03_02_functional.py
import tensorflow.keras as keras
import numpy as np


# 퀴즈
# AND 데이터셋에 대해 동작하는 케라스 모델을 구축하세요
def and_sequential():
    data = [[0, 0, 0],
            [0, 1, 0],
            [1, 0, 0],
            [1, 1, 1]]
    data = np.int32(data)

    x = data[:, :-1]
    y = data[:, -1:]

    model = keras.Sequential()
    model.add(keras.layers.InputLayer([2]))
    model.add(keras.layers.Dense(2, activation='relu'))
    model.add(keras.layers.Dense(1, activation='sigmoid'))
    model.summary()

    model.compile(optimizer=keras.optimizers.SGD(0.1),
                  loss=keras.losses.binary_crossentropy,
                  metrics='acc')

    model.fit(x, y, epochs=100, verbose=2)


def and_functional():
    data = [[0, 0, 0],
            [0, 1, 0],
            [1, 0, 0],
            [1, 1, 1]]
    data = np.int32(data)

    x = data[:, :-1]
    y = data[:, -1:]

    # 1번
    # inputs = keras.layers.Input([2])
    # dense1 = keras.layers.Dense(2, activation='relu')
    # dense2 = keras.layers.Dense(1, activation='sigmoid')
    #
    # output1 = dense1.__call__(inputs)
    # output2 = dense2.__call__(output1)

    # 2번
    # inputs = keras.layers.Input([2])
    # dense1 = keras.layers.Dense(2, activation='relu')
    # dense2 = keras.layers.Dense(1, activation='sigmoid')
    #
    # output1 = dense1(inputs)
    # output2 = dense2(output1)

    # 3번
    # inputs = keras.layers.Input([2])
    #
    # output1 = keras.layers.Dense(2, activation='relu')(inputs)
    # output2 = keras.layers.Dense(1, activation='sigmoid')(output1)
    #
    # model = keras.Model(inputs, output2)

    # 4번
    inputs = keras.layers.Input([2])

    output = keras.layers.Dense(2, activation='relu')(inputs)
    output = keras.layers.Dense(1, activation='sigmoid')(output)

    model = keras.Model(inputs, output)
    model.summary()

    model.compile(optimizer=keras.optimizers.SGD(0.1),
                  loss=keras.losses.binary_crossentropy,
                  metrics='acc')

    model.fit(x, y, epochs=10, verbose=2)


def functional_input():
    data = [[0, 0, 0],
            [0, 1, 0],
            [1, 0, 0],
            [1, 1, 1]]
    data = np.int32(data)

    x1 = data[:, 0:1]
    x2 = data[:, 1:2]
    y  = data[:, 2:3]

    inputs1 = keras.layers.Input([1])
    output1 = keras.layers.Dense(4, activation='relu', name='output1-1')(inputs1)
    output1 = keras.layers.Dense(2, activation='relu', name='output1-2')(output1)

    inputs2 = keras.layers.Input([1])
    output2 = keras.layers.Dense(4, activation='relu', name='output2-1')(inputs2)
    output2 = keras.layers.Dense(2, activation='relu', name='output2-2')(output2)

    concat = keras.layers.concatenate([output1, output2])
    output = keras.layers.Dense(1, activation='sigmoid')(concat)

    model = keras.Model([inputs1, inputs2], output)
    model.summary()

    model.compile(optimizer=keras.optimizers.SGD(0.1),
                  loss=keras.losses.binary_crossentropy,
                  metrics='acc')

    model.fit([x1, x2], y, epochs=10, verbose=2)


# 퀴즈
# XOR 데이터를 추가하고 출력을 두 개로 확장한 모델을 만드세요
def functional_input_output():
    data = [[0, 0, 0, 0],
            [0, 1, 0, 1],
            [1, 0, 0, 1],
            [1, 1, 1, 0]]
    data = np.int32(data)

    x1 = data[:, 0:1]
    x2 = data[:, 1:2]
    y1 = data[:, 2:3]
    y2 = data[:, 3:4]

    inputs1 = keras.layers.Input([1])
    output1 = keras.layers.Dense(4, activation='relu')(inputs1)
    output1 = keras.layers.Dense(2, activation='relu')(output1)

    inputs2 = keras.layers.Input([1])
    output2 = keras.layers.Dense(4, activation='relu')(inputs2)
    output2 = keras.layers.Dense(2, activation='relu')(output2)

    concat = keras.layers.concatenate([output1, output2])

    output3 = keras.layers.Dense(2, activation='relu')(concat)
    output3 = keras.layers.Dense(1, activation='sigmoid')(output3)

    output4 = keras.layers.Dense(2, activation='relu')(concat)
    output4 = keras.layers.Dense(1, activation='sigmoid')(output4)

    model = keras.Model([inputs1, inputs2], [output3, output4])
    model.summary()

    model.compile(optimizer=keras.optimizers.SGD(0.1),
                  loss=keras.losses.binary_crossentropy,
                  metrics='acc')

    model.fit([x1, x2], [y1, y2], epochs=10, verbose=2)


# and_sequential()
# and_functional()
# functional_input()
functional_input_output()






