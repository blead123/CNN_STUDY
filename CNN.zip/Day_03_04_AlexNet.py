# Day_03_04_AlexNet.py
import tensorflow.keras as keras


# slim 라이브러리에 포함된 lenet 코드
# net = slim.conv2d(images, 32, [5, 5], scope='conv1')
# net = slim.max_pool2d(net, [2, 2], 2, scope='pool1')
# net = slim.conv2d(net, 64, [5, 5], scope='conv2')
# net = slim.max_pool2d(net, [2, 2], 2, scope='pool2')
# net = slim.flatten(net)
#
# net = slim.fully_connected(net, 1024, scope='fc3')
# net = slim.dropout(net, 0.5, is_training=is_training, scope='dropout3')
# logits = slim.fully_connected(net, 10, activation_fn='softmax', scope='fc4')


# 퀴즈
# slim 라이브러리에 포함된 AlexNet 코드를 케라스 버전으로 변환하세요
# net = slim.conv2d(inputs, 64, [11, 11], 4, padding='VALID', scope='conv1')
# net = slim.max_pool2d(net, [3, 3], 2, scope='pool1')
# net = slim.conv2d(net, 192, [5, 5], scope='conv2')
# net = slim.max_pool2d(net, [3, 3], 2, scope='pool2')
# net = slim.conv2d(net, 384, [3, 3], scope='conv3')
# net = slim.conv2d(net, 384, [3, 3], scope='conv4')
# net = slim.conv2d(net, 256, [3, 3], scope='conv5')
# net = slim.max_pool2d(net, [3, 3], 2, scope='pool5')
#
# net = slim.conv2d(net, 4096, [5, 5], padding='VALID', scope='fc6')
# net = slim.dropout(net, 0.5, is_training=is_training, scope='dropout6')
# net = slim.conv2d(net, 4096, [1, 1], scope='fc7')
# net = slim.dropout(net, 0.5, is_training=is_training, scope='dropout7')
# net = slim.conv2d( net, 1000, [1, 1], activation_fn='softmax')
# net = tf.squeeze(net, [1, 2], name='fc8/squeezed')

model = keras.Sequential()
model.add(keras.layers.InputLayer([224, 224, 3]))

model.add(keras.layers.Conv2D(64, [11, 11], 4, 'valid', activation='relu'))
model.add(keras.layers.MaxPool2D([3, 3], 2, 'valid'))
model.add(keras.layers.Conv2D(192, [5, 5], 1, 'same', activation='relu'))
model.add(keras.layers.MaxPool2D([3, 3], 2, 'valid'))
model.add(keras.layers.Conv2D(384, [3, 3], 1, 'same', activation='relu'))
model.add(keras.layers.Conv2D(384, [3, 3], 1, 'same', activation='relu'))
model.add(keras.layers.Conv2D(256, [3, 3], 1, 'same', activation='relu'))
model.add(keras.layers.MaxPool2D([3, 3], 2, 'valid'))

model.add(keras.layers.Conv2D(4096, [5, 5], 1, 'valid', activation='relu'))
model.add(keras.layers.Dropout(0.5))
model.add(keras.layers.Conv2D(4096, [1, 1], 1, activation='relu'))
model.add(keras.layers.Dropout(0.5))
model.add(keras.layers.Conv2D(1000, [1, 1], 1))
model.add(keras.layers.Flatten())
model.add(keras.layers.Activation('softmax'))

model.summary()
